#include <windows.h>
#include <cmath>
#include <time.h>
// define bytebeat
#pragma comment(lib, "winmm.lib")

// rgbquad definition

typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;

// the payloads

DWORD WINAPI vista(LPVOID lpParam)
{
    HDC hdc = GetDC(0);

    int y = GetSystemMetrics(0);
    int x = GetSystemMetrics(0);

    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(0);

    for (int i = 2; i < 333; i++) {
        BitBlt(hdc, rand() % i + i, rand() % i, sw, x, hdc, 0, 0, SRCCOPY);
        BitBlt(hdc, rand() % i, rand() % i + i, sh, y, hdc, 0, 0, SRCCOPY);

    }
}


DWORD WINAPI whirls(LPVOID lpParam)
{
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN), xSize = sh/10, ySize = 9;
    while (1) {
    	HDC desk = GetDC(0);
        for (int i = 0; i < sh*2; i++) {
            int wave = sin(i / ((float)xSize) * M_PI) * (ySize);
            BitBlt(desk, i, 0, 1, sh, desk, i, wave, SRCCOPY);
        }
        for (int i = 0; i < sw*2; i++) {
            int wave = sin(i / ((float)xSize) * M_PI) * (ySize);
            BitBlt(desk, 0, i, sw, 1, desk, wave, i, SRCCOPY);
        }
    }
}

DWORD WINAPI trich(LPVOID lpParam)
{
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			//INT x = i % w, y = i / w;
			rgbScreen[i].rgb -= 666;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		Sleep(100);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}

DWORD WINAPI rgb(LPVOID lpParam)
{
    HWND v3; 
    HBITMAP h; 
    HDC hdcSrc; 
    HDC hdc; 
    void* lpvBits;
    int nHeight; 
    int nWidth; 
    DWORD v12; 
    int j; 
    int v14; 
    int i; 
    v12 = GetTickCount();
    nWidth = GetSystemMetrics(0);
    nHeight = GetSystemMetrics(1);
    lpvBits = VirtualAlloc(0, 4 * nWidth * (nHeight + 1), 0x3000u, 4u);
    for (i = 0; ; i = (i + 1) % 2)
    {
        hdc = GetDC(0);
        hdcSrc = CreateCompatibleDC(hdc);
        h = CreateBitmap(nWidth, nHeight, 1u, 0x20u, lpvBits);
        SelectObject(hdcSrc, h);
        BitBlt(hdcSrc, 0, 0, nWidth, nHeight, hdc, 0, 0, 0xCC0020u);
        GetBitmapBits(h, 4 * nHeight * nWidth, lpvBits);
        v14 = 0;
        if (GetTickCount() - v12 > 0xA)
            rand();
        for (j = 0; nHeight * nWidth > j; ++j)
        {
            if (!(j % nHeight) && !(rand() % 110))
                v14 = rand() % 24;
            *((BYTE*)lpvBits + 4 * j + v14) -= 5;
        }
        SetBitmapBits(h, 4 * nHeight * nWidth, lpvBits);
        BitBlt(hdc, 0, 0, nWidth, nHeight, hdcSrc, 0, 0, 0xCC0020u);
        DeleteObject(h);
        DeleteObject(hdcSrc);
        DeleteObject(hdc);
    }

}

DWORD WINAPI textout(LPVOID lpParam)
{
    int x = GetSystemMetrics(0); int y = GetSystemMetrics(1);
    LPCSTR text = 0;
    LPCSTR text1 = 0;
    LPCSTR text2 = 0;
    LPCSTR text3 = 0;
    while(1)
    {
        HDC hdc = GetDC(0);
        SetBkMode(hdc, 0);
        text = "HEM J10841+4325",
        text1 = "What? Help me!";
        text2 = "Tubercomiosis + Vistamations";
        text3 = "ENJOY THE BEEPING, BAAAAAAAAA";
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        HFONT font = CreateFontA(43, 32, 0, 0, FW_THIN, 0, 1, 0, ANSI_CHARSET, 0, 0, 0, 0, "Baby Kruffy");
        SelectObject(hdc, font);
        TextOutA(hdc, rand() % x, rand() % y, text, strlen(text));
        Sleep(10);
        TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
        Sleep(10);
        TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));
        Sleep(10);
        TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
        DeleteObject(font);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI icons(LPVOID lpParam)
{
    while (1)
    {
        HDC hdc = GetDC(0);
        int x = rand() % GetSystemMetrics(SM_CXSCREEN);
        int y = rand() % GetSystemMetrics(SM_CYSCREEN);
        HMODULE hModule = LoadLibrary(TEXT("user32.dll"));
        int randomIcon = rand() % (250 - 50 + 1) + 50;
        HICON hIcon = LoadIcon(hModule, MAKEINTRESOURCE(randomIcon));
        ICONINFO iconInfo;
        GetIconInfo(hIcon, &iconInfo);
        BITMAP bmpIcon;
        GetObject(iconInfo.hbmColor, sizeof(BITMAP), &bmpIcon);
        int iconWidth = bmpIcon.bmWidth;
        int iconHeight = bmpIcon.bmHeight;
        DrawIconEx(hdc, x, y, hIcon, iconWidth * 9, iconHeight * 9, 0, NULL, DI_NORMAL);
        ReleaseDC(0, hdc);
        Sleep(1);
        FreeLibrary(hModule);
    }
} 

DWORD WINAPI darkener(LPVOID lpParam)
{
    HDC hdc;
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    while (1) {
        hdc = GetDC(0);
        BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
        Sleep(10);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI sierpinski(LPVOID lpParam)
{
    int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
        HDC desk = GetDC(NULL);
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        SelectObject(hdcdc, hbm);
	BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 0; w * h > i; i++) {
		int x = i % w, y = i / h, t = y ^ y | x;
		data[i].rgb = x & y & t;
        }
        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm);
        DeleteObject(hdcdc);
        DeleteObject(desk);
    }
    return 0;
} 

DWORD WINAPI squr(LPVOID lpParam)
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int x = 10;
    int y = 10;
	while(1){
		HDC hdc = GetDC(0);
        x += incrementor * signX;
        y += incrementor * signY;
		int top_x = 0 + x;
        int top_y = 0 + y;
        int bottom_x = 100 + x;
        int bottom_y = 100 + y; 
    	HBRUSH brush = CreateSolidBrush(RGB(0, 0, 255));
    	SelectObject(hdc, brush);
		Rectangle(hdc, top_x, top_y, bottom_x, bottom_y);
        if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
                signY = -1;
        }
        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -1;
        }
        if (y == 0)
        {
            signY = 1;
        }
        if (x == 0)
        {
            signX = 1;
        }
        Sleep(10);
    	DeleteObject(brush);
        ReleaseDC(0, hdc);
	}
}

DWORD WINAPI beziers(LPVOID lpParam)
{
	int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    while(1){
    	HDC hdc = GetDC(0);
		POINT p[4]  = {rand() % sw, rand() % sh, rand() % sw, rand() % sh,  rand() % sw, rand() % sh};
        HPEN hPen = CreatePen(PS_SOLID,5,RGB(0,0,255));
        SelectObject(hdc, hPen);
		PolyBezier(hdc, p, 4);
    	DeleteObject(hPen);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI train(LPVOID lpParam)
{
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    while (1) {
        HDC hdc = GetDC(0);
    	HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdc, brush);
        BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, 0x1900ac010e);
    	DeleteObject(brush);
        ReleaseDC(0, hdc);
        Sleep(rand() % 100);
    }
}

DWORD WINAPI spin(LPVOID lpParam)
{
    HDC hWindow;
    HDC hDsktp;
    HWND hWnd;
    RECT wRect;
    int dX = 0;
    int dY = 0;
    int dW;
    int dH;
    POINT lppoint[3];
    int counter = 30;
    while (true)
    {
        hWnd = GetDesktopWindow();
        hWindow = GetWindowDC(hWnd);
        hDsktp = GetDC(0);
        GetWindowRect(hWnd, &wRect);
        dW = GetSystemMetrics(0);
        dH = GetSystemMetrics(0);
        lppoint[0].x = wRect.left + counter;
        lppoint[0].y = wRect.top - counter;
        lppoint[1].x = wRect.right + counter;
        lppoint[1].y = wRect.top + counter;
        lppoint[2].x = wRect.left - counter;
        lppoint[2].y = wRect.bottom - counter;
        PlgBlt(hDsktp, lppoint, hDsktp, wRect.left, wRect.top, wRect.right - wRect.left, wRect.bottom - wRect.top, 0, 0, 0);
        if (counter < 15) counter++;
        if (counter < 65) counter--;
        ReleaseDC(0,  hDsktp);
    }
} 

DWORD WINAPI masg(LPVOID lpParam)
{
	while (1) {
		MessageBoxW(NULL, L"What a horrible decision you've made!", L"SAY BYE TO PC", MB_OKCANCEL | MB_ICONERROR);
	}
	return 0;
}

DWORD WINAPI beepbeep(LPVOID lpParam)
{
	while (1) {
		Beep(rand () % 2555, rand () % 25);
	}
}

// malware
 
int main () {
	if (MessageBoxW(NULL, L"You are currently about to run the HEM J10841+4325.exe GDI Trojan made by Tubercomiosis99 and Vistamations. Continue?", L"What? Help me! Help = No", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure? It contains flashing lights, so be wary!", L"Huh???", MB_OKCANCEL | MB_ICONEXCLAMATION) == IDCANCEL)
		{
			ExitProcess(0);
		}
		else
		{
			Sleep(7000);
			HANDLE z = CreateThread(0, 0, masg, 0, 0, 0);
			Sleep(1000);
			HANDLE a = CreateThread(0, 0, vista, 0, 0, 0);
			Sleep(15000);
			TerminateThread(a, 0);
			CloseHandle(a);
		InvalidateRect(0, 0, 0);
			HANDLE b = CreateThread(0, 0, whirls, 0, 0, 0);
			HANDLE c = CreateThread(0, 0, trich, 0, 0, 0);
			Sleep(15000);
			TerminateThread(b, 0);
			TerminateThread(c, 0);
			CloseHandle(b);
		InvalidateRect(0, 0, 0);
			CloseHandle(c);
		InvalidateRect(0, 0, 0);
			HANDLE d = CreateThread(0, 0, rgb, 0, 0, 0);
			HANDLE e = CreateThread(0, 0, textout, 0, 0, 0);
			Sleep(15000);
			TerminateThread(d, 0);
			TerminateThread(e, 0);
			CloseHandle(d);
		InvalidateRect(0, 0, 0);
			CloseHandle(e);
		InvalidateRect(0, 0, 0);
			HANDLE f = CreateThread(0, 0, icons, 0, 0, 0);
			HANDLE g = CreateThread(0, 0, darkener, 0, 0, 0);
			Sleep(15000);
			TerminateThread(f, 0);
			TerminateThread(g, 0);
			CloseHandle(f);
		InvalidateRect(0, 0, 0);
			CloseHandle(g);
		InvalidateRect(0, 0, 0);
			HANDLE h = CreateThread(0, 0, sierpinski, 0, 0, 0);
			Sleep(15000);
			TerminateThread(h, 0);
			CloseHandle(h);
		InvalidateRect(0, 0, 0);
			HANDLE i = CreateThread(0, 0, squr, 0, 0, 0);
			HANDLE j = CreateThread(0, 0, icons, 0, 0, 0);
			Sleep(15000);
			TerminateThread(i, 0);
			TerminateThread(j, 0);
			CloseHandle(i);
		InvalidateRect(0, 0, 0);
			CloseHandle(j);
		InvalidateRect(0, 0, 0);
			HANDLE k = CreateThread(0, 0, beziers, 0, 0, 0);
			HANDLE l = CreateThread(0, 0, whirls, 0, 0, 0);
			Sleep(15000);
			TerminateThread(k, 0);
			TerminateThread(l, 0);
			CloseHandle(k);
		InvalidateRect(0, 0, 0);
			CloseHandle(l);
		InvalidateRect(0, 0, 0);
			HANDLE m = CreateThread(0, 0, train, 0, 0, 0);
			HANDLE n = CreateThread(0, 0, icons, 0, 0, 0);
			Sleep(15000);
			TerminateThread(m, 0);
			TerminateThread(n, 0);
			CloseHandle(m);
		InvalidateRect(0, 0, 0);
			CloseHandle(m);
		InvalidateRect(0, 0, 0);
			HANDLE o = CreateThread(0, 0, spin, 0, 0, 0);
			HANDLE p = CreateThread(0, 0, textout, 0, 0, 0);
			Sleep(15000);
			TerminateThread(o, 0);
			TerminateThread(p, 0);
			TerminateThread(z, 0);
			CloseHandle(o);
		InvalidateRect(0, 0, 0);
			CloseHandle(p);
		InvalidateRect(0, 0, 0);
		}
	}
}
